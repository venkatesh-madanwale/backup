export interface Product {
  _id?: string;
  name: string;
  desc: string;
  price: number;
  cat: string;
  pimg?: string;
}